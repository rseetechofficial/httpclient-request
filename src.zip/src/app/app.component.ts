import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit{
  title = 'Http Client';

  constructor(private httpClient : HttpClient) { }
  private users : any[];

  private name : string;
  private email : string;
  private phone : number;
  private username : string;
  private website : string;
  private company : string;
  private address : string;

  ngOnInit(){

    this.httpClient.get('../assets/users.json').subscribe(

      (res : any)=>{

        console.log("Users list", res);
        this.users = res;
      }
    )

  }

  showData(userdetails){
    console.log(userdetails);
     this.email = userdetails.email;
     this.name = userdetails.name;
     this.phone = userdetails.phone;
     this.username = userdetails.username;
     this.website = userdetails.website;
     this.company = userdetails.company;
     this.address = userdetails.address;

 }
}
